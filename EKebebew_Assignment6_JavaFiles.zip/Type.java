public enum Type {
	COFFEE,
	SMOOTHIE,
	ALCOHOL
}