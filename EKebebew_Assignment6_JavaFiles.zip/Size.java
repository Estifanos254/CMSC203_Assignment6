/*Class: CMSC203Â 21754
 * Instructor: Prof Grinberg
 * Description: (this is enum size.)
 * Due: 12/14/2022
 * Platform/compiler: Eclipse
* I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
 Print your Name here: __Estifanos Kebebew________
*/

public enum Size {
	SMALL, MEDIUM,
	LARGE
}